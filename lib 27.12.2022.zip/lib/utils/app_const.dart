import 'package:flutter/cupertino.dart';

// const BASEURL = "http://192.168.100.112:8074";

// const BASEURL = "http://192.168.1.9:8074";

const BASEURL = "http://94.74.117.238";
const version = 'Version 27.12.2022';

//const BASEURL = "http://192.168.84.240:8074";

//const BASEURL = "http://192.168.200.216:8074";

class AppColors {
  static const Color appBarColor = Color.fromARGB(255, 12, 41, 92);
}
