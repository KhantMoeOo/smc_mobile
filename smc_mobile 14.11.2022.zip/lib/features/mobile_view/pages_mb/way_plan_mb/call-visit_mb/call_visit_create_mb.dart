import 'package:dropdown_search2/dropdown_search2.dart';
import 'package:flutter/material.dart';
import 'package:smc_mobile/pages/profile_page/profile_bloc.dart';
import 'package:smc_mobile/pages/quotation_page/quotation_bloc.dart';
import 'package:smc_mobile/pages/way_planning_page/schedule_page/schedule_bloc.dart';

import '../../../../../obs/response_ob.dart';
import '../../../../../utils/app_const.dart';

class CallVisitCreateMB extends StatefulWidget {
  const CallVisitCreateMB({Key? key}) : super(key: key);

  @override
  State<CallVisitCreateMB> createState() => _CallVisitCreateMBState();
}

class _CallVisitCreateMBState extends State<CallVisitCreateMB> {
  final scheduleBloc = ScheduleBloc();
  final quotationBloc = QuotationBloc();
  final profileBloc = ProfileBloc();

  bool hasNotTownship = true;
  bool hasTownshipData = false;
  int townshipId = 0;
  String townshipName = '';
  List<dynamic> townshipList = [];

  bool hasNotCustomer = true;
  bool hasCustomerData = false;
  int customerId = 0;
  String customerName = '';
  List<dynamic> customerList = [];

  List<dynamic> userList = [];

  bool hasNotOrderDate = true;
  String dateOrder = '';
  final dateOrderController = TextEditingController();

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    scheduleBloc.getTownshipListData(filter: ['id', 'ilike', '']);
    scheduleBloc.getTownshipListStream().listen(getTownshipListListen);
    profileBloc.getResUsersData();
    profileBloc.getResUsersStream().listen(getResUsersData);
    quotationBloc.getCustomerStream().listen(getCustomerListListen);
    dateOrderController.text = DateTime.now().toString().split(' ')[0];
    hasNotOrderDate = false;
  }

  void getResUsersData(ResponseOb responseOb) {
    if (responseOb.msgState == MsgState.data) {
      userList = responseOb.data;
      if (userList.isNotEmpty) {
        quotationBloc.getCustomerList(
          ['id', 'ilike', ''],
          ['zone_id.id', '=', userList[0]['zone_id'][0]],
        );
      }
    }
  }

  void getCustomerListListen(ResponseOb responseOb) {
    if (responseOb.msgState == MsgState.data) {
      setState(() {
        hasCustomerData = true;
        customerList = responseOb.data;
      });
    }
  }

  void getCustomerId(String? v) {
    if (v != null) {
      setState(() {
        customerId = int.parse(v.toString().split(',')[0]);
        hasNotCustomer = false;
        for (var element in customerList) {
          if (element['id'] == customerId) {
            customerName = element['name'];
            customerId = element['id'];
            print('customerName:$customerName');
            print('customerId:$customerId');
          }
        }
      });
    } else {
      hasNotCustomer = true;
    }
  }

  void getTownshipListListen(ResponseOb responseOb) {
    if (responseOb.msgState == MsgState.data) {
      setState(() {
        hasTownshipData = true;
        townshipList = responseOb.data;
      });
    }
  }

  void getTownshipId(String? v) {
    if (v != null) {
      setState(() {
        townshipId = int.parse(v.toString().split(',')[0]);
        hasNotTownship = false;
        for (var element in townshipList) {
          if (element['id'] == townshipId) {
            townshipName = element['name'];
            townshipId = element['id'];
            print('townshipName:$townshipName');
            print('townshipId:$townshipId');
          }
        }
      });
    } else {
      hasNotTownship = true;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[200],
      appBar: AppBar(
        backgroundColor: AppColors.appBarColor,
        title: const Text('New'),
      ),
      body: ListView(padding: const EdgeInsets.all(10.0), children: [
        Text(
          "Township*:",
          style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
              color: hasNotTownship == true ? Colors.red : Colors.black),
        ),
        const SizedBox(
          height: 10,
        ),
        Container(
          color: Colors.white,
          height: 40,
          child: StreamBuilder<ResponseOb>(
              initialData: hasTownshipData == false
                  ? ResponseOb(msgState: MsgState.loading)
                  : null,
              stream: scheduleBloc.getTownshipListStream(),
              builder: (context, AsyncSnapshot<ResponseOb> snapshot) {
                ResponseOb? responseOb = snapshot.data;
                if (responseOb?.msgState == MsgState.loading) {
                  return Center(
                    child: Image.asset(
                      'assets/gifs/loading.gif',
                      width: 100,
                      height: 100,
                    ),
                  );
                } else if (responseOb?.msgState == MsgState.error) {
                  if (responseOb?.errState == ErrState.severErr) {
                    return Container(
                        height: 50,
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Center(
                                child: Text('${responseOb?.data}',
                                    style: const TextStyle(
                                        fontWeight: FontWeight.bold,
                                        color: Colors.red))),
                            IconButton(
                                onPressed: () {
                                  scheduleBloc.getTownshipListData(
                                      filter: ['id', 'ilike', '']);
                                },
                                icon: const Icon(Icons.refresh))
                          ],
                        ));
                  } else if (responseOb?.errState == ErrState.noConnection) {
                    return SizedBox(
                        height: 50,
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            const Center(
                                child: Text('No Internet Connection!',
                                    style: TextStyle(
                                        fontWeight: FontWeight.bold,
                                        color: Colors.red))),
                            IconButton(
                                onPressed: () {
                                  scheduleBloc.getTownshipListData(
                                      filter: ['id', 'ilike', '']);
                                },
                                icon: const Icon(Icons.refresh))
                          ],
                        ));
                  } else {
                    return SizedBox(
                        height: 50,
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            const Center(
                                child: Text('Unknown Error!',
                                    style: TextStyle(
                                        fontWeight: FontWeight.bold,
                                        color: Colors.red))),
                            IconButton(
                                onPressed: () {
                                  scheduleBloc.getTownshipListData(
                                      filter: ['id', 'ilike', '']);
                                },
                                icon: const Icon(Icons.refresh))
                          ],
                        ));
                  }
                } else {
                  return DropdownSearch<String>(
                    popupItemBuilder: (context, item, isSelected) {
                      return Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(item.toString().split(',')[1]),
                            const Divider(),
                          ],
                        ),
                      );
                    },
                    autoValidateMode: AutovalidateMode.onUserInteraction,
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Please select Township Name';
                      }
                      return null;
                    },
                    showSearchBox: true,
                    showSelectedItems: true,
                    // showClearButton: !hasNotCustomer,
                    items: townshipList.map((e) {
                      return '${e['id']},${e['name']}';
                    }).toList(),
                    onChanged: getTownshipId,
                    dropdownBuilder: (c, i) {
                      return Text(i == null
                          ? ''
                          : i.contains(',')
                              ? i.toString().split(',')[1]
                              : i);
                    },
                    selectedItem: townshipName,
                  );
                }
              }),
        ),
        const SizedBox(
          height: 10,
        ),
        Text(
          "Customer*:",
          style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
              color: hasNotCustomer == true ? Colors.red : Colors.black),
        ),
        const SizedBox(
          height: 10,
        ),
        Container(
          color: Colors.white,
          height: 40,
          child: StreamBuilder<ResponseOb>(
              initialData: hasCustomerData == false
                  ? ResponseOb(msgState: MsgState.loading)
                  : null,
              stream: quotationBloc.getCustomerStream(),
              builder: (context, AsyncSnapshot<ResponseOb> snapshot) {
                ResponseOb? responseOb = snapshot.data;
                if (responseOb?.msgState == MsgState.loading) {
                  return Center(
                    child: Image.asset(
                      'assets/gifs/loading.gif',
                      width: 100,
                      height: 100,
                    ),
                  );
                } else if (responseOb?.msgState == MsgState.error) {
                  if (responseOb?.errState == ErrState.severErr) {
                    return Container(
                        height: 50,
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Center(
                                child: Text('${responseOb?.data}',
                                    style: const TextStyle(
                                        fontWeight: FontWeight.bold,
                                        color: Colors.red))),
                            IconButton(
                                onPressed: () {
                                  quotationBloc.getCustomerList(
                                    ['id', 'ilike', ''],
                                    [
                                      'zone_id.id',
                                      '=',
                                      userList[0]['zone_id'][0]
                                    ],
                                  );
                                },
                                icon: const Icon(Icons.refresh))
                          ],
                        ));
                  } else if (responseOb?.errState == ErrState.noConnection) {
                    return SizedBox(
                        height: 50,
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            const Center(
                                child: Text('No Internet Connection!',
                                    style: TextStyle(
                                        fontWeight: FontWeight.bold,
                                        color: Colors.red))),
                            IconButton(
                                onPressed: () {
                                  quotationBloc.getCustomerList(
                                    ['id', 'ilike', ''],
                                    [
                                      'zone_id.id',
                                      '=',
                                      userList[0]['zone_id'][0]
                                    ],
                                  );
                                },
                                icon: const Icon(Icons.refresh))
                          ],
                        ));
                  } else {
                    return SizedBox(
                        height: 50,
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            const Center(
                                child: Text('Unknown Error!',
                                    style: TextStyle(
                                        fontWeight: FontWeight.bold,
                                        color: Colors.red))),
                            IconButton(
                                onPressed: () {
                                  quotationBloc.getCustomerList(
                                    ['id', 'ilike', ''],
                                    [
                                      'zone_id.id',
                                      '=',
                                      userList[0]['zone_id'][0]
                                    ],
                                  );
                                },
                                icon: const Icon(Icons.refresh))
                          ],
                        ));
                  }
                } else {
                  return DropdownSearch<String>(
                    popupItemBuilder: (context, item, isSelected) {
                      return Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(item.toString().split(',')[1]),
                            const Divider(),
                          ],
                        ),
                      );
                    },
                    autoValidateMode: AutovalidateMode.onUserInteraction,
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Please select Customer Name';
                      }
                      return null;
                    },
                    showSearchBox: true,
                    showSelectedItems: true,
                    // showClearButton: !hasNotCustomer,
                    items: customerList.map((e) {
                      return '${e['id']},${e['name']}';
                    }).toList(),
                    onChanged: getCustomerId,
                    dropdownBuilder: (c, i) {
                      return Text(i == null
                          ? ''
                          : i.contains(',')
                              ? i.toString().split(',')[1]
                              : i);
                    },
                    selectedItem: customerName,
                  );
                }
              }),
        ),
        const SizedBox(
          height: 10,
        ),
        Text(
          "Date*:",
          style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
              color: hasNotOrderDate == true ? Colors.red : Colors.black),
        ),
        const SizedBox(height: 10),
        Container(
            color: Colors.white,
            height: 40,
            child: TextFormField(
                readOnly: true,
                autovalidateMode: AutovalidateMode.onUserInteraction,
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please select Quotation Date';
                  }
                  return null;
                },
                controller: dateOrderController,
                decoration: InputDecoration(
                    border: const OutlineInputBorder(),
                    suffixIcon: IconButton(
                      icon: const Icon(Icons.arrow_drop_down),
                      onPressed: () async {
                        final DateTime? selected = await showDatePicker(
                            context: context,
                            initialDate: DateTime.now(),
                            firstDate: DateTime.now(),
                            lastDate: DateTime(2023));

                        if (selected != null) {
                          setState(() {
                            dateOrder = '${selected.toString().split(' ')[0]}}';
                            dateOrderController.text =
                                '${selected.toString().split(' ')[0]}}';
                            hasNotOrderDate = false;
                            print(dateOrder);
                          });
                        }
                      },
                    )))),
        const SizedBox(
          height: 10,
        ),
        
      ]),
    );
  }
}
