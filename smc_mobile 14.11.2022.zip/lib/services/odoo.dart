import 'package:odoo_api/odoo_api.dart';

class Odoo extends OdooClient {
  Odoo(String serverURL) : super(serverURL);
}
