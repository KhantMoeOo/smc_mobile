import 'package:flutter/cupertino.dart';

const BASEURL = "http://192.168.100.17:8074";

// const BASEURL = "http://192.168.1.15:8074";

// const BASEURL = "http://94.74.117.238";
const version = 'Version 10.11.2022';

//const BASEURL = "http://192.168.84.240:8074";

//const BASEURL = "http://192.168.200.216:8074";

class AppColors {
  static const Color appBarColor = Color.fromARGB(255, 12, 41, 92);
}
